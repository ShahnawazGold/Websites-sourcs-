<?php

define('DB_HOST','localhost');
define('DB_USER','root');
define('DB_PASSS','');
define('DB_NAME','phpblog');


?>
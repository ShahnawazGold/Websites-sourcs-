<?php

class database{
	
	public $host=DB_HOST;
	public $user=DB_USER;
	public $pass=DB_PASSS;
	public $db_name=DB_NAME;
	
	public $link ;
	public $error ;
	
	public function __construct(){
		$this->connect();
		
	}
	
	
	private function connect(){
		
	$this->link= new mysqli ($this->host,$this->user,$this->pass,$this->db_name);	
	if($this->link){
		 
		$this->error ="connection failed ".this->link->connect_error ;	
	}
	}

	
	public  function  select ($query){
	
	$result=$this->link->query($query);
	
	if($result->num_rows>0){
		return $result;
		
	}
}


	public  function insert ($query){
	
	$insert=$this->link->query($query);
	
	if($insert){
		
		header('location:indux.php?insert= Post inserted...');
	}else{
		echo"did  not insert";
	}
}


	public  function update ($query){
	
	$update=$this->link->query($query);
	
	if($update){
		
		header('location:indux.php?insert= Post updated...');
	}else{
		echo"did  not update";
	}
}


	public  function delete($query){
	
	$delete=$this->link->query($query);
	
	if($delete){
		
		header('location:indux.php?insert= Post deleted...');
	}else{
		echo"did  not delete";
	}
}


	
}


?>
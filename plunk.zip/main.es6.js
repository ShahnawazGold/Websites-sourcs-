import {Component} from 'angular2/core';
import {bootstrap} from 'angular2/platform/browser';


@Component({
  selector: 'app',
  providers: [Service],
  template: '{{greeting}} world!'
})
class App {
  constructor(service: Service) {
    this.greeting = service.greeting();
    setTimeout(() => this.greeting = 'Howdy,', 1000);
  }
}

class Service {
  greeting() {
    return 'Hello';
  }
}

bootstrap(App);